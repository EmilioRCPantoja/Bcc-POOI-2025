package com.poo.lista.exercicio3.dominio;

public enum TipoDeCarroceria {
    HATCH,
    SEDAN,
    SUV
}
