package com.poo.lista.exercicio3.dominio;

public enum TipoDeCarro {
    CITADINO,
    UTILITARIO,
    FAMILIAR,
    FURGAO
}
